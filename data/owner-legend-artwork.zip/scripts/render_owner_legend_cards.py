#!/usr/bin/env python3
"""Preserve, reconcile and render the owner's PPW Legends photo intake.

Requires local originals staged from user uploads, no external downloads,
no synthetic faces or likenesses. Outputs ARE DRAFT and not rights-cleared.
"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw, ImageFilter, ImageFont, ImageEnhance
import csv, hashlib, io, json, math, os, re, zipfile, glob, shutil

ROOT=Path(os.environ.get('PPW_LEGEND_SOURCE_DIR','data/.owner-legend-intake'))
STAGE=ROOT/'stage'
OUT=ROOT/'rendered'
ASSETS=OUT/'assets'/'legends'
PREVIEW=OUT/'previews'
for d in (STAGE,ASSETS,PREVIEW):d.mkdir(parents=True,exist_ok=True)
SUBJECTS='''Shane Douglas|Tommy Dreamer|The Sandman|Lance Storm|Mike Awesome|Haku|Doink the Clown|Owen Hart|Rick Rude|Bam Bam Bigelow|Brian Pillman|Jake Roberts|Diamond Dallas Page|Big Show|Rob Van Dam|Lex Luger|Ted DiBiase|Sgt. Slaughter|Sid Vicious|Mark Henry|Big Boss Man|Nick Bockwinkel|Barry Windham|Tully Blanchard|Kerry Von Erich|Rick Martel|Paul Orndorff|The Iron Sheik|Ken Shamrock|Bray Wyatt|Brodie Lee|PAC|Rikishi|X-Pac|The Honky Tonk Man|Rhyno|Abyss|Jay Briscoe|Hayabusa|Triple H|Batista|Roddy Piper|Goldberg|Yokozuna|Hiroshi Tanahashi|Kane|AJ Styles|Daniel Bryan|Jerry Lawler|The Ultimate Warrior|Brock Lesnar|Bruiser Brody|Superstar Billy Graham|John Cena|Harley Race|Lou Thesz|Verne Gagne|Molly Holly|Gail Kim|Victoria|Awesome Kong|Sensational Sherri|Luna Vachon|Devil Masami|Wendi Richter|Akira Hokuto|Meiko Satomura|Madusa|Mildred Burke|The Dudley Boyz|Bubba Ray Dudley|D-Von Dudley|The Steiner Brothers|Rick Steiner|Scott Steiner|Demolition|Ax|Smash|The Midnight Express|Bobby Eaton|Stan Lane|The British Bulldogs|Davey Boy Smith|Dynamite Kid|The Outsiders|Scott Hall|Kevin Nash|The Wild Samoans|Afa|Sika|APA|Bradshaw|Ron Simmons|Beer Money Inc.|Bobby Roode|James Storm|The Natural Disasters|Earthquake|Typhoon|The Fabulous Freebirds|Michael Hayes|Terry Gordy|Buddy Roberts|Terry Funk'''.split('|')
assert len(SUBJECTS)==104
TEAM_MEMBERS={
 'The Dudley Boyz':['Bubba Ray Dudley','D-Von Dudley'],
 'The Steiner Brothers':['Rick Steiner','Scott Steiner'],
 'Demolition':['Ax','Smash'],
 'The Midnight Express':['Bobby Eaton','Stan Lane'],
 'The British Bulldogs':['Davey Boy Smith','Dynamite Kid'],
 'The Outsiders':['Scott Hall','Kevin Nash'],
 'The Wild Samoans':['Afa','Sika'],
 'APA':['Bradshaw','Ron Simmons'],
 'Beer Money Inc.':['Bobby Roode','James Storm'],
 'The Natural Disasters':['Earthquake','Typhoon'],
 'The Fabulous Freebirds':['Michael Hayes','Terry Gordy','Buddy Roberts'],
}
TEAM_TIER={
'The Dudley Boyz':'ICON','The Steiner Brothers':'ICON','Demolition':'ICON',
'The Midnight Express':'LEGEND','The British Bulldogs':'LEGEND','The Outsiders':'ICON',
'The Wild Samoans':'LEGEND','APA':'LEGEND','Beer Money Inc.':'LEGEND',
'The Natural Disasters':'LEGEND','The Fabulous Freebirds':'ICON'
}
SINGLES=SUBJECTS[:69]+['Terry Funk']
assert len(SINGLES)==70 and len(TEAM_MEMBERS)==11
TIER={}
for name in SUBJECTS[:7]:TIER[name]='CULT'
for name in SUBJECTS[7:39]:TIER[name]='LEGEND'
for name in SUBJECTS[39:53]:TIER[name]='ICON'
for name in ['John Cena','Harley Race','Terry Funk','Lou Thesz','Verne Gagne']:TIER[name]='IMMORTAL'
for name in SUBJECTS[57:65]:TIER[name]='LEGEND'
for name in SUBJECTS[65:68]:TIER[name]='ICON'
TIER['Mildred Burke']='IMMORTAL'
assert len({x for x in SINGLES if x in TIER})==70,[(x,TIER.get(x)) for x in SINGLES if x not in TIER]
for name,tier in TEAM_TIER.items():TIER[name]=tier

PALETTE={'CULT':('#7CA6CA','#213C59'),'LEGEND':('#F1BB5A','#58411F'),'ICON':('#58D3F6','#123F57'),'IMMORTAL':('#CF94FA','#43285C')}
DEJAVU='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
DEJAVU_LIGHT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FAMILY='/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'
font=lambda pt,serif=False,normal=False:ImageFont.truetype(FAMILY if serif else DEJAVU_LIGHT if normal else DEJAVU,pt)

def rgb(h):return tuple(int(h[i:i+2],16) for i in (1,3,5))
def slug(s):return re.sub('-+','-',re.sub(r'[^a-z0-9]+','-',s.lower())).strip('-')
def fitfont(d,txt,maximum,start=68,minsize=23,serif=True):
 for pt in range(start,minsize-1,-1):
  f=font(pt,serif=serif)
  if d.textbbox((0,0),txt,font=f)[2] <=maximum:return f
 return font(minsize,serif=serif)
def centered(d,xy,text,f,fill):d.text(xy,text,font=f,anchor='mm',fill=fill,stroke_width=0)

sources=[]
for z in sorted(ROOT.glob('PPW_Legends_Original_Photos_Batch_*.zip')):
 with zipfile.ZipFile(z) as f:
  for name in sorted(f.namelist()):
   n=int(Path(name).name.split('_')[0]);sources.append((n,Path(name).name,f.read(name)))
for n,path in enumerate(sorted((ROOT/'late_uploads').glob('image*.png')),start=82):
 sources.append((n,path.name,path.read_bytes()))
sources.sort(key=lambda a:a[0]);assert len(sources)==104

photo_map={}
for (n,filename,b),expected in zip(sources,SUBJECTS):
 im=Image.open(io.BytesIO(b));sha=hashlib.sha256(b).hexdigest()
 tag=f'{n:03d}_{slug(expected)}{Path(filename).suffix}'
 staged=STAGE/tag
 if not staged.exists() or staged.read_bytes()!=b: staged.write_bytes(b)
 photo_map[expected]={'position':n,'source_filename':filename,'staged_filename':tag,
 'sha256':sha,'bytes':len(b),'width':im.width,'height':im.height,
 'quality_note':('REVIEW_LOW_RES' if min(im.width,im.height)<500 else 'STANDARD'),
 'attribution':'Owner-uploaded original. Photograph copyright/likeness release not verified.',
 'mapping_basis':('owner-confirmed final Terry Funk upload' if expected=='Terry Funk'
      else 'owner-confirmed delayed Freebirds group' if expected=='The Fabulous Freebirds'
      else 'owner-provided ordered checklist with excluded entries and named late insertions')}

with (OUT/'photo-intake-104.csv').open('w',newline='',encoding='utf-8') as f:
 writer=csv.writer(f);writer.writerow(['position','photo_subject','source_file','staged_file','sha256','width','height','quality_note','mapping_basis'])
 for x in SUBJECTS:
  d=photo_map[x];writer.writerow([d['position'],x,d['source_filename'],d['staged_filename'],d['sha256'],d['width'],d['height'],d['quality_note'],d['mapping_basis']])

W,H=960,1440

def gradient(size,top,bottom):
 a=Image.new('RGB',(1,size[1]),top);px=a.load()
 for y in range(size[1]):
  r=y/(size[1]-1);px[0,y]=tuple(round(top[i]*(1-r)+bottom[i]*r) for i in range(3))
 return a.resize(size)

def add_photo(background,src,rect,team=False):
 x,y,w,h=rect
 im=Image.open(src).convert('RGBA')
 # Trim only genuine transparent empty canvas; never crop opaque team photos.
 # This lets the original photographed subject fill the collector card while
 # preserving the full silhouette and all team members.
 alpha=im.getchannel('A')
 if alpha.getextrema()[0]<250:
  bbox=alpha.point(lambda a:255 if a>15 else 0).getbbox()
  if bbox:
   margin_x=max(6,int((bbox[2]-bbox[0])*.025))
   margin_y=max(6,int((bbox[3]-bbox[1])*.025))
   crop=(max(0,bbox[0]-margin_x),max(0,bbox[1]-margin_y),
         min(im.width,bbox[2]+margin_x),min(im.height,bbox[3]+margin_y))
   im=im.crop(crop)
 image=Image.new('RGBA',im.size,(23,34,50,255));image.alpha_composite(im)
 # Atmospheric crop stays behind the original; all members stay in frame on team cards.
 base=ImageOps.fit(image.convert('RGB'),(w,h),method=Image.Resampling.LANCZOS,centering=(.5,.34)).filter(ImageFilter.GaussianBlur(35))
 base=ImageEnhance.Brightness(base).enhance(.3)
 background.paste(base,(x,y))
 fitted=ImageOps.contain(im,(w-28,h-30),Image.Resampling.LANCZOS)
 px=x+(w-fitted.width)//2;py=y+(h-fitted.height)//2
 background.paste(fitted,(px,py),fitted)

# Card geometry follows the already delivered 48 PPW Legend card design.
# The image window and footer are separate. The rarity badge never occupies
# the photo area, including any transparent or group-photo composition.
CARD_DESIGN_VERSION='LEGACY_48_FRAME_SEPARATE_RARITY_BADGE_V1'
CARD_LAYOUT={
 'photo':(53,162,907,1063),
 'header':(54,46,906,143),
 'footer':(53,1081,907,1370),
 'badge':(348,1090,612,1142),
 'nameplate':(75,1157,885,1285),
}
# y-axis contract — two non-intersecting regions, so no badge ever hides a face.
assert CARD_LAYOUT['photo'][3] < CARD_LAYOUT['badge'][1]
assert CARD_LAYOUT['badge'][3] < CARD_LAYOUT['nameplate'][1]
assert CARD_LAYOUT['photo'][0] <= CARD_LAYOUT['badge'][0]
assert CARD_LAYOUT['badge'][2] <= CARD_LAYOUT['photo'][2]
def draw_card(name,source,tier,is_team=False,members=None):
 primary,secondary=PALETTE[tier];a=rgb(primary);s=rgb(secondary)
 # Exactly the established 48-card template: deep graphite base,
 # triple border, separated photo, collector header, serif nameplate.
 legacy_dim={
  'CULT':(29,48,66),'LEGEND':(63,41,14),
  'ICON':(13,53,67),'IMMORTAL':(55,28,78),
 }[tier]
 canvas=Image.new('RGB',(W,H),(7,10,17))
 d=ImageDraw.Draw(canvas)
 for inset,color in ((5,a),(15,(35,40,54)),(25,legacy_dim)):
  d.rounded_rectangle((inset,inset,W-inset-1,H-inset-1),radius=22,
                      outline=color,width=3 if inset==5 else 2)
 d.rounded_rectangle(CARD_LAYOUT['header'],radius=16,
                     fill=(11,14,25),outline=a,width=3)
 centered(d,(W//2,76),'P P W   /   L E G E N D S',font(28), (247,246,252))
 centered(d,(W//2,120),'THE '+tier+' COLLECTION',font(29),a)
 x1,y1,x2,y2=CARD_LAYOUT['photo']
 add_photo(canvas,source,(x1,y1,x2-x1,y2-y1),is_team)
 d=ImageDraw.Draw(canvas)
 d.rectangle((x1-4,y1-4,x2+4,y2+4),outline=a,width=4)
 d.rounded_rectangle(CARD_LAYOUT['footer'],radius=18,fill=(11,14,25),outline=a,width=3)
 # Agreed fix: the badge is in its OWN lower band, immediately above
 # the nameplate. It NEVER overlays the photo or a wrestler's face.
 d.rounded_rectangle(CARD_LAYOUT['badge'],radius=22,fill=s,outline=a,width=3)
 centered(d,(W//2,1116),tier,font(30), (255,255,255))
 d.rounded_rectangle(CARD_LAYOUT['nameplate'],radius=15,
                     fill=(12,19,32),outline=a,width=2)
 # Long tag-team names wrap without shrinking below legibility.
 def title_parts(title):
  if len(title)<=22:return [title]
  words=title.split();result=['','']
  for word in words:
   k=0 if len(result[0])<len(title)/2 else 1
   result[k]=(result[k]+' '+word).strip()
  return result
 lines=title_parts(name.upper())
 if len(lines)==1:
  title=fitfont(d,lines[0],W-190,73 if not is_team else 62,minsize=28,serif=True)
  centered(d,(W//2,1221),lines[0],title,(250,249,252))
 else:
  for i,line in enumerate(lines[:2]):
   title=fitfont(d,line,W-190,56,minsize=28,serif=True)
   centered(d,(W//2,1195+i*54),line,title,(250,249,252))
 label='TAG TEAM  •  '+str(len(members or []))+' MEMBERS' if is_team else 'SINGLES LEGEND'
 centered(d,(W//2,1320),label,font(24),a)
 # Keep tier treatment limited to border, header and footer.
 # No duplicate top-right photo badge and no graphical cover over faces.
 canvas.save(ASSETS/(slug(name)+'-'+tier.lower()+'-card.webp'),format='WEBP',quality=86,method=5)

def draw_portrait(name,src,tier,member=False):
 w,h=480,624;primary,_=PALETTE[tier];a=rgb(primary)
 canvas=gradient((w,h),(19,27,44),(38,44,60))
 add_photo(canvas,src,(8,8,w-16,h-16),False)
 d=ImageDraw.Draw(canvas)
 d.rounded_rectangle((5,5,w-6,h-6),radius=15,outline=a,width=5)
 canvas.save(ASSETS/(slug(name)+'-portrait.webp'),format='WEBP',quality=87,method=5)

index=[]
for name in SINGLES:
 tier=TIER[name];src=STAGE/photo_map[name]['staged_filename']
 draw_card(name,src,tier)
 draw_portrait(name,src,tier)
 index.append({'name':name,'tier':tier,'kind':'SINGLE','card':slug(name)+'-'+tier.lower()+'-card.webp','portraits':[slug(name)+'-portrait.webp'],'member_names':[name]})
for name,members in TEAM_MEMBERS.items():
 tier=TIER[name];src=STAGE/photo_map[name]['staged_filename']
 draw_card(name,src,tier,True,members)
 for member in members:draw_portrait(member,STAGE/photo_map[member]['staged_filename'],tier,True)
 index.append({'name':name,'tier':tier,'kind':'TEAM','card':slug(name)+'-'+tier.lower()+'-card.webp','portraits':[slug(m)+'-portrait.webp' for m in members],'member_names':members})
assert len(index)==81 and sum(len(x['portraits']) for x in index)==93
with (OUT/'legend-render-manifest.json').open('w') as f:json.dump({'version':1,'title':'PPW Legend expansion - source-backed draft','rights_status':'PRIVATE_HOBBY_DRAFT_NOT_RIGHTS_CLEARED','source_count':104,'card_count':81,'portrait_count':93,'card_design_version':CARD_DESIGN_VERSION,'card_layout':CARD_LAYOUT,'photo_map':photo_map,'legends':index},f,indent=2)

# Contact-sheet of NEW cards, with tier and title visible enough to assess layout.
for tier in PALETTE:
 items=[x for x in index if x['tier']==tier]
 sheet=Image.new('RGB',(5*230,math.ceil(len(items)/5)*375),(12,18,30))
 for i,x in enumerate(items):
  im=Image.open(ASSETS/x['card']).convert('RGB')
  im.thumbnail((218,340),Image.Resampling.LANCZOS)
  cx=(i%5)*230+(230-im.width)//2;cy=(i//5)*375+8
  sheet.paste(im,(cx,cy))
 sheet.save(PREVIEW/('cards-'+tier.lower()+'-preview.jpg'),quality=88)

# Keep original upload bytes in an immutable intake archive for provenance.
with zipfile.ZipFile(OUT/'PPW_Legends_104_Owner_Sources.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in SUBJECTS:z.write(STAGE/photo_map[name]['staged_filename'],arcname=photo_map[name]['staged_filename'])
 z.write(OUT/'photo-intake-104.csv',arcname='photo-intake-104.csv')

with zipfile.ZipFile(OUT/'PPW_Legends_81_Cards_93_Portraits_DRAFT.zip','w',compression=zipfile.ZIP_STORED) as z:
 for p in sorted(ASSETS.glob('*.webp')):z.write(p,arcname='apps/web/public/assets/legends/'+p.name)
 z.write(OUT/'legend-render-manifest.json',arcname='data/owner-legend-render-manifest.json')
 z.write(OUT/'photo-intake-104.csv',arcname='data/owner-legend-photo-intake.csv')

print(json.dumps({'originals':len(sources),'cards':len(index),'portraits':sum(map(lambda x:len(x['portraits']),index)),'tier_counts':dict(Counter(x['tier'] for x in index)),'min_res_review':[(k,v['width'],v['height']) for k,v in photo_map.items() if v['quality_note']!='STANDARD'],'files':[(p.name,p.stat().st_size) for p in sorted(OUT.glob('*.zip'))]},indent=2))
