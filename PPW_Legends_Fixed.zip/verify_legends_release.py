#!/usr/bin/env python3
"""PPW user-source Legends draft release guard. Run at repo root.

Rejects missing cards, incorrect person ID assignments, source swaps,
incorrect output dimensions and any change to the existing Undertaker pilot.
"""
from pathlib import Path
from PIL import Image
import sys,json,re,hashlib,collections

ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
manifest_path=ROOT/'data/legend-user-artwork-manifest.json'
manifest=json.loads(manifest_path.read_text())
assert manifest['edition']=='USER_SUPPLIED_LEGENDS_ARTWORK_DRAFT_2026_10_26'
assert manifest['undertaker']=='EXISTING_PILOT_UNCHANGED'
assert len(manifest['entries'])==manifest['cards']==47
assert manifest['rosterPortraits']==48
assert len({m['id'] for m in manifest['entries']})==47
asset_root=ROOT/'apps/web/public/assets/legends'
seen_people=set();files=set();fail=[]
def check(p,expect,digest):
    assert p.is_file(),f'Missing {p}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,f'Changed pixels {p}'
    with Image.open(p) as im:
        assert im.size==expect,f'Incorrect dimensions {p}, {im.size}, wanted {expect}'
        assert im.format=='WEBP',f'Incorrect format {p}'
        assert im.mode in ('RGB','RGBA'),f'Incorrect color mode {p}'
        if im.mode=='RGBA':
            a=im.getchannel('A')
            assert a.getextrema()==(255,255),f'Unexpected alpha in finished art: {p}'
    files.add(p.name)
for m in manifest['entries']:
    id=m['id'];tier=m['tier'].lower()
    path=m['cardAsset']
    assert path==f'/assets/legends/{id}-{tier}-card.webp',f'Wrong card path {id}'
    check(asset_root/Path(path).name,(960,1440),m['cardSha256'])
    assert len(m['portraits'])==(2 if id=='road-warriors' else 1),f'Wrong team size: {id}'
    for i,person in enumerate(m['portraits']):
        assert person['personId']==f'legend:{id}:{i}',f'Wrong person ID {person}'
        assert person['asset']==f'/assets/legends/{id}-{i}-portrait.webp',f'Wrong image {person}'
        check(asset_root/Path(person['asset']).name,(480,624),person['sha256'])
        assert person['personId'] not in seen_people
        seen_people.add(person['personId'])
    assert m['photoRights']=='USER_SUPPLIED_DRAFT_UNVERIFIED'
assert len(files)==95 and len(seen_people)==48
# Explicitly do not include an Undertaker source or overwrite the Undertaker pilot.
assert not any(name.startswith('undertaker') for name in files)
print('PASS: 47 collectible cards, 48 wrestler portraits; user source hashes, identity map and Undertaker exclusion verified')
