# PPW Phase 17 — restore the *original 48* Legends user-supplied artwork

This is the 26 October 2026 vetted **offline** artwork, repackaged to apply to the latest PPW Phase 17 draft. No gameplay, source records, or saved Worlds are included.

**Audit finding (29 October 2026):** the active Phase 17 branch contains all original Legend files, but its 47 original non-Undertaker cards and 48 per-person portraits are bytewise different from the submitted, offline-prepared versions. Taz currently displays the sunglasses profile (Jennifer/Commons), whereas the user-supplied original `taz.png` and the corrected card show a full standing wrestler pose. The approved Undertaker pilot has the same blob across the original Phase 8 branch and Phase 17 and is intentionally excluded.

**Contents:** 47 original Legend cards at their current exact URL paths (960x1440 WebP), 48 original wrestler portraits at their stable person-ID URLs (480x624 WebP), a SHA-256/identity manifest, original rendering contact sheets, and an offline installer/verifier. The other 81 new Legends cards/portraits are NOT included and MUST NOT change. The collectible remains separate from a wrestler signing.

**No action has been taken against GitHub/Production to replace these 95 binary images.** Until these files are integrated, users may still see the old pictures. Do not confuse this download with a deployed fix.

## Applying to the *draft* Phase 17 checkout

```sh
unzip PPW_Phase17_Original_48_Legends_Artwork_Restore.zip -d /tmp/ppw-legacy-art
cd /tmp/ppw-legacy-art
python verify_legends_release.py overlay
python install_to_repo.py --repo /path/to/Project-Professional-Wrestling-Rebuild --dry-run
python install_to_repo.py --repo /path/to/Project-Professional-Wrestling-Rebuild
python /path/to/Project-Professional-Wrestling-Rebuild/scripts/verify_legends_release.py /path/to/Project-Professional-Wrestling-Rebuild
```

The installer refuses a checkout on `main` or `master`, changes only the original 47 card + 48 portrait binary paths, installs a manifest/verifier, and corrects 47 obsolete source credits while preserving Undertaker's verified credit. Make a coherent draft commit only after checking `git diff --stat`, 129-Legend packaging, TypeScript/PWA build, 320px/390px reveals, existing-unlock/album behaviour, and disposable PostgreSQL tests.

**Do not merge, deploy Vercel, migrate live Neon, advance World, or activate any cron without owner authorisation.** Photography rights for user-supplied images remain unverified; this is a private playtest draft, not clearance to publish or redistribute.
