#!/usr/bin/env python3
"""Apply the reviewed Oct-26 Legends pack to a checked-out Phase 17 PPW rebuild repo.

This is a local/offline installer; never deploys, migrates or advances the World.
Run once before final CI with --repo <checkout>. All assets are versioned under
apps/web/public and the Undertaker pilot is intentionally never touched.
"""
from pathlib import Path
import argparse,shutil,subprocess,json,re,hashlib

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--overlay',type=Path,default=Path(__file__).parent/'overlay')
p.add_argument('--dry-run',action='store_true')
a=p.parse_args()
repo=a.repo.resolve();overlay=a.overlay.resolve()
assert (repo/'src/domain/legends-catalogue.ts').is_file(), 'Not a PPW repository checkout'
assert (repo/'src/content/legend-card-photo-credits.ts').is_file(),'Requires the PPW Rebuild repository'
if (repo/'.git').exists():
    branch=subprocess.check_output(['git','-C',str(repo),'branch','--show-current'],text=True).strip()
    assert branch and branch not in ('main','master'), 'Refusing to modify main; checkout an approved draft branch'

manifest=json.loads((overlay/'data/legend-user-artwork-manifest.json').read_text())
entries=manifest['entries']
assets=overlay/'apps/web/public/assets/legends'
assert len(list(assets.glob('*.webp')))==95
cards=repo/'apps/web/public/assets/legends'
source=repo/'src/content/legend-card-photo-credits.ts'
code=source.read_text()
for row in entries:
    slug=row['id'];tier=row['tier'];
    pattern=r'  "'+re.escape(slug)+r'": \{[\s\S]*?\n  \},'
    entry='  '+json.dumps(slug)+': {\n'+\
        '    "author": "User-supplied draft photo; original photographer unverified",\n'+\
        '    "license": "Unverified - private draft",\n'+\
        '    "sourcePage": "",\n'+\
        '    "tier": '+json.dumps(tier)+'\n  },'
    code,n=re.subn(pattern,lambda _:entry,code,count=1)
    assert n==1,f'Missing existing photo credit mapping for {slug}'
assert re.search(r'  "undertaker": \{',code),'Undertaker credit must be preserved'
ui=repo/'src/ui/legends-vault.ts'
s=ui.read_text()
needle=' const source=document.createElement("a");'
assert needle in s,'Unexpected Legends Vault UI markup; inspect before applying'
# Modern Phase 17 already supports missing public credits. Avoid duplicate logic.
if 'if(!credit.sourcePage)' not in s:
    replace=' if(!credit.sourcePage){\n  caption.append(el("span","",credit.license+" · user-supplied draft"));\n  return caption;\n }\n'+needle
    assert s.count(needle)==1
    s=s.replace(needle,replace,1)
# Strictly avoid executing any game code, touching .env, deploying or committing.
if a.dry_run:
    print('DRY-RUN OK:',len(entries),'catalogue mappings, 95 static image files, Undertaker untouched')
else:
    cards.mkdir(parents=True,exist_ok=True)
    for fp in assets.glob('*.webp'):
        assert not fp.name.startswith('undertaker')
        shutil.copy2(fp,cards/fp.name)
    (repo/'data').mkdir(parents=True,exist_ok=True)
    (repo/'scripts').mkdir(parents=True,exist_ok=True)
    shutil.copy2(overlay/'data/legend-user-artwork-manifest.json',repo/'data/legend-user-artwork-manifest.json')
    shutil.copy2(Path(__file__).parent/'verify_legends_release.py',repo/'scripts/verify_legends_release.py')
    source.write_text(code)
    ui.write_text(s)
    print('INSTALLED: 47 draft cards, 48 exact person portraits, source credits and QA guard. Undertaker untouched.')
